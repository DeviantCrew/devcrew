export type onReadyParams = {
    isReady: boolean;
};
