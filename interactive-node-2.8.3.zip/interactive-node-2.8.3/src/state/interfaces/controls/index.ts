/**
 * @deprecated etags are no longer used, you can always omit/ignore this
 */
export type ETag = string;

export * from './IButton';
export * from './IControl';
export * from './IInput';
export * from './IJoystick';
export * from './ILabel';
export * from './IScreen';
export * from './ITextbox';
export * from './IMeta';
